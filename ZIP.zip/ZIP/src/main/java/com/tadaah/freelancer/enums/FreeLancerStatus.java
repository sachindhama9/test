package com.tadaah.freelancer.enums;

public enum FreeLancerStatus {
    NEW_FREELANCER, VERIFIED, MARKED_FOR_DELETION
}
